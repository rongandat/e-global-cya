<?php

	define('_HTTP_ADMIN_SITE_ROOT',_HTTP_SITE_ROOT.'/gwpanel');
	define('_ADMIN_ROOT',_SITE_ROOT.'gwpanel/');
	define('_ADMIN_INCLUDES','includes/');
	define('_ADMIN_LANGUAGE_DIR',_ADMIN_ROOT.'languages/');
	define('_DEFAULT_ADMIN_LANGUAGE','english');
	
	define('_IMAGE_FRONTEND_PARTIES_WS_DIR','../images/');
	define('_IMAGE_FRONTEND_ROOT',_SITE_ROOT.'images/');	
	
	define('_FRONTEND_HTTP_SITE_ROOT',HTTP_SERVER.'/');

	
?>