<?php /* Smarty version 2.6.18, created on 2012-06-03 06:29:12
         compiled from home/exchangers.html */ ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<div align="right">
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="650" id="AutoNumber35">
  <tr>
	<td width="100%" height="20">&nbsp;</td>
  </tr>
  <tr>
	<td width="100%" height="40" valign="top">
		<font face="Tahoma" size="3" color="#800000"><a name="top"><b>Our 
        Digital Money Exchangers</b> </a>
		</font></td>
  </tr>
  <tr>
	<td width="100%" valign="top">
	<blockquote>
	  <font face="Tahoma" size="2">To <b>buy, sell</b> or <b>
	  Deposit, Withdraw</b> Global Cash amount, chose your country or city to 
	  find your best digital currency exchangers in this list. or 
	  all exchangers available service by online.</font></blockquote>
	</td>
  </tr>
</table>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber37" height="217">
  <tr>
	<td width="33%" valign="top" height="217">
	<ul>
	  <li><font face="Tahoma" size="2">
	  <a href="#United States (USA)">United States (USA)</a></font></li>
	  <li><font face="Tahoma" size="2">
	  <a href="#United Kingdom (UK)">United Kingdom (UK)</a></font></li>
	  <li><font face="Tahoma" size="2">
	  <a href="#Russian Federation">Russian Federation</a></font></li>
	</ul>
	</td>
	<td width="33%" valign="top" height="217">
	<ul>
	  <li><font size="2" face="Tahoma"><a href="#Hong Kong">Hong Kong</a></font></li>
	  <li><font size="2" face="Tahoma"><a href="#South Korea">South Korea</a></font></li>
	  <li><font size="2" face="Tahoma"><a href="#Singapore">
	  Singapore</a></font></li>
	  <li><font size="2" face="Tahoma"><a href="#China">China</a></font></li>
	  <li><font size="2" face="Tahoma"><a href="#Japan">Japan</a></font></li>
	  <li><font size="2" face="Tahoma"><a href="#Indonesia">Indonesia</a></font></li>
	  <li><font size="2" face="Tahoma"><a href="#Thailand">Thailand</a></font></li>
	</ul>
	</td>
	<td width="34%" valign="top" height="217">
	<ul>
	  <li><font size="2" face="Tahoma"><a href="#UAE">UAE</a></font></li>
	  <li><font face="Tahoma" size="2"><a href="#Saudi Arabia">Saudi Arabia</a></font></li>
	  <li><font size="2" face="Tahoma"><a href="#India">India</a></font></li>
	  <li><font face="Tahoma" size="2"><a href="#Nigeria">Nigeria</a></font></li>
	  <li><font face="Tahoma" size="2"><a href="#Senegal">Senegal</a></font></li>
	</ul>
	</td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber38">
  <tr>
	<td width="100%" height="30" valign="top"><b>
	<font face="Tahoma" size="2" color="#800000">
	<a name="United States (USA)">United States (USA)</a></font></b></td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse" bordercolor="#808080" width="600" id="AutoNumber39">
  <tr>
	<td width="16%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Company</b></font></td>
	<td width="16%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Added</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Payment</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Supported</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>GDCA</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Notes</b></font></td>
  </tr>
  <tr>
	<td width="16%" valign="top">
                        <font face="Tahoma" size="2">
                        <a id="dlExchanger_ctl00_HyperLink13" target="_blank" href="http://www.e-dollars.co/">
    e-dollars.co</a></font></td>
	<td width="16%" valign="top">
    <p align="center"><font face="Tahoma" size="2">15.10.2011</font></td>
	<td width="17%" valign="top"><font size="2" face="Tahoma">Wire transfer, 
    credit cards</font></td>
	<td width="17%" valign="top">
    <p align="center"><font size="2" face="Tahoma">English</font></td>
	<td width="17%" valign="top">
    <p align="center"><font size="2" face="Tahoma">No</font></td>
	<td width="17%" valign="top"><font size="2" face="Tahoma">US corporation, a 
    digital currency sales and exchanges service company </font></td>
  </tr>
  <tr>
	<td width="16%" valign="top">
    <p align="center"><font size="2" face="Tahoma">
    <a target="_blank" href="http://centregold.com/">Centregold.ca</a></font></td>
	<td width="16%" valign="top">
    <p align="center"><font size="2" face="Tahoma">30.05.2009</font></td>
	<td width="17%" valign="top"><font size="2" face="Tahoma">Wire transfer, 
    credit cards</font></td>
	<td width="17%" valign="top">
    <p align="center"><font size="2" face="Tahoma">English</font></td>
	<td width="17%" valign="top">
    <p align="center"><font size="2" face="Tahoma">Yes</font></td>
	<td width="17%" valign="top"><font size="2" face="Tahoma">Canadian 
    corporation, a digital currency sales and exchanges service company </font></td>
  </tr>
  <tr>
	<td width="16%" valign="top">
    <font face="Tahoma" size="2">
    <a target="_blank" href="http://getemoney.com/">Getemoney.com</a></font></td>
	<td width="16%" valign="top">
    <p align="center"><font face="Tahoma" size="2">May 2008</font></td>
	<td width="17%" valign="top"><font face="Tahoma" size="2">Bank wires, cash 
    deposits, postal money order (Canada only), bank draft (Canada only) and 
    other in Canada. Liberty Reserve, e-gold, e-bullion, c-gold</font></td>
	<td width="17%" valign="top">
    <p align="center"><font face="Tahoma" size="2">English, French</font></td>
	<td width="17%" valign="top">
    <p align="center"><font face="Tahoma" size="2">No</font></td>
	<td width="17%" valign="top"><font face="Tahoma" size="2">In business since 
    august 2000 serving thousand of customers. </font></td>
  </tr>
  </table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber40" height="36">
  <tr>
	<td width="100%" height="30" valign="bottom">
	<p align="right"><b><font face="Tahoma" size="2"><a href="#top">
	Back to Top</a></font></b></td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber41" height="105">
  <tr>
	<td width="100%" height="50">&nbsp;</td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber42">
  <tr>
	<td width="100%" height="30" valign="top"><b>
	<font size="2" face="Tahoma" color="#800000">
	<a name="United Kingdom (UK)">United Kingdom (UK)</a></font></b></td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse" bordercolor="#808080" width="600" id="AutoNumber43">
  <tr>
	<td width="16%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Company</b></font></td>
	<td width="16%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Added</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Payment</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Supported</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>GDCA</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Notes</b></font></td>
  </tr>
  <tr>
	<td width="16%" valign="top">
    <a target="_blank" href="http://absolutexchange.eu">
    <img border="0" src="http://e-globalcash.net/banners/absex.jpg" width="170" height="41"></a></td>
	<td width="16%" valign="top">
    <p align="center"><font size="2" face="Tahoma">01.03.2009</font></td>
	<td width="17%" valign="top"><font size="2" face="Tahoma">Wire transfer, 
    Western Union, Cash deposit</font></td>
	<td width="17%" valign="top">
    <p align="center"><font size="2" face="Tahoma">English</font></td>
	<td width="17%" valign="top">
    <p align="center"><span lang="ja"><font size="2" face="Tahoma">Yes</font></span></td>
	<td width="17%" valign="top"><font size="2" face="Tahoma">Liberty Reserve, 
    Pecunix, EuroGoldCash, StrictPay, PayPal, C-gold, Gold-Pay. Excellent 
    Service. Since 2007. </font></td>
  </tr>
  <tr>
	<td width="16%" valign="top"><font size="2" face="Tahoma">
    <a href="http://www.wmbroker.co.uk/">wmbroker.co.uk</a></font></td>
	<td width="16%" valign="top"><font size="2" face="Tahoma">2009-07-05</font></td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top"><font size="2" face="Tahoma">English</font></td>
	<td width="17%" valign="top">
    <p align="center"><span lang="ja"><font size="2" face="Tahoma">Yes</font></span></td>
	<td width="17%" valign="top"><font size="2" face="Tahoma">Using our service 
    you can Buy and Sell electronic currencies (Webmoney, E-Gold, PayPal) by 
    WIRE transfer. All operations with E-Gold can be permitted using our current 
    exchange course WMZ / E-Gold. </font></td>
  </tr>
  </table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber44" height="36">
  <tr>
	<td width="100%" height="30" valign="bottom">
	<p align="right"><b><font face="Tahoma" size="2"><a href="#top">
	Back to Top</a></font></b></td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber45" height="105">
  <tr>
	<td width="100%" height="50">&nbsp;</td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber46">
  <tr>
	<td width="100%" height="30" valign="top"><b>
	<font size="2" face="Tahoma" color="#800000">
	<a name="Russian Federation">Russian Federation</a></font></b></td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse" bordercolor="#808080" width="600" id="AutoNumber47">
  <tr>
	<td width="16%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Company</b></font></td>
	<td width="16%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Added</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Payment</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Supported</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>GDCA</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Notes</b></font></td>
  </tr>
  <tr>
	<td width="16%" valign="top">
    <p align="center"><font size="2" face="Tahoma">
    <a href="http://insta-change.com">
    <img border="0" src="http://e-globalcash.net/banners/instachange.png" align="left" width="115" height="70"></a></font></td>
	<td width="16%" valign="top"><font size="2" face="Tahoma">7/13/2010 12:00:00 
    AM</font></td>
	<td width="17%" valign="top"><font size="2" face="Tahoma">Credit Cards, wire 
    transfers</font></td>
	<td width="17%" valign="top"><font size="2" face="Tahoma">English, Russian</font></td>
	<td width="17%" valign="top">
    <p align="center"><font size="2" face="Tahoma">Yes</font></td>
	<td width="17%" valign="top"><font size="2" face="Tahoma">Simple and safe 
    operations concerning exchange, buying and selling of the e-currencies. 
    Exchange Liberty Reserve, Perfect Money, EuroGoldCash, AlertPay, 
    GlobalDigitalPay and Webmoney.</font></td>
  </tr>
  <tr>
	<td width="16%" valign="top"><font size="2" face="Tahoma">
    <a target="_blank" href="http://www.liliontransfer.org/">
    <img border="0" src="http://e-globalcash.net/banners/LilionTransferLogo170x85.png" width="170" height="85"></a></font></td>
	<td width="16%" valign="top"><font size="2" face="Tahoma">01.04.2011</font></td>
	<td width="17%" valign="top"><font size="2" face="Tahoma">Bank wires </font></td>
	<td width="17%" valign="top"><font size="2" face="Tahoma">Chech, Danish, 
    German, English, Spanish, Finnish, French, Hungary, Italian, Dutch, Norway, 
    Polish, Potruguese, Romanian, Russian, Slovenian, Serbian, Swedish, Turkish, 
    Ukrainian</font></td>
	<td width="17%" valign="top">
    <p align="center"><font size="2" face="Tahoma">Yes</font></td>
	<td width="17%" valign="top"><font size="2" face="Tahoma">Express funding 
    and withdrawal via Lilion Transfer!<br>
    Bank Wire (12 Currencies): PLN, CZK, RUB, NOK, SEK, DKK, GBP, EUR, CHF, USD, 
    CAD, AUD.<br>
    E-Transfer (11 E-currencies): LR, PM, GDP, MNT, EPP, PP, MB, AP, HD, OK, EGC.<br>
    Exchange e-money into GOLD AND SILVER BARS AND COINS with home delivery 
    worldwide.<br>
    Over 50 bank accounts worldwide. Less than 2 hours service. </font></td>
  </tr>
  </table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber48" height="36">
  <tr>
	<td width="100%" height="30" valign="bottom">
	<p align="right"><b><font face="Tahoma" size="2"><a href="#top">
	Back to Top</a></font></b></td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber49" height="105">
  <tr>
	<td width="100%" height="50">&nbsp;</td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber50">
  <tr>
	<td width="100%" height="30" valign="top"><b>
	<font size="2" face="Tahoma" color="#800000">
	<a name="Hong Kong">Hong Kong</a></font></b></td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse" bordercolor="#808080" width="600" id="AutoNumber51">
  <tr>
	<td width="16%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Company</b></font></td>
	<td width="16%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Added</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Payment</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Supported</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>GDCA</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Notes</b></font></td>
  </tr>
  <tr>
	<td width="16%" valign="top">
    <a target="_blank" href="http://www.cyberex.jp/">
    <img border="0" src="http://e-globalcash.net/banners/cebanner125x100.gif" alt="Cyber Exchange Service Japan" width="125" height="100"></a></td>
	<td width="16%" valign="top">
    <p align="center"><span lang="ja"><font face="Tahoma" size="2">07</font></span><font size="2" face="Tahoma">.0<span lang="ja">5</span>.20<span lang="ja">10</span></font></td>
	<td width="17%" valign="top"><font size="2" face="Tahoma">Visa, Mastercard, 
    Wire transfer, Western Union, PayPal, Local Bank deposits in Hong Kong</font>
    <font size="2" face="Tahoma">(Online Banking, ATM)</font></td>
	<td width="17%" valign="top">
    <p align="center"><span lang="ja"><font size="2" face="Tahoma">English </font></span></td>
	<td width="17%" valign="top">
    <p align="center"><span lang="ja"><font size="2" face="Tahoma">Yes</font></span></td>
	<td width="17%" valign="top"><font size="2" face="Tahoma">We provide major 
    e-currency exchange service (Buy, Sell, and swap e-currency services. all 
    Buy, Sell, swap e-currency available).</font></td>
  </tr>
  <tr>
	<td width="16%" valign="top">
    <font size="2" face="Tahoma"><a target="_blank" href="http://ebuygold.com/">Ebuygold.com</a></font></td>
	<td width="16%" valign="top">
    <p align="center"><font face="Tahoma" size="2">Mar 2008</font></td>
	<td width="17%" valign="top"><font face="Tahoma" size="2">Bank Wire, Western 
    Union. </font></td>
	<td width="17%" valign="top">
    <p align="center"><font face="Tahoma" size="2">English, Chinese</font></td>
	<td width="17%" valign="top">
    <p align="center"><font face="Tahoma" size="2">No</font></td>
	<td width="17%" valign="top"><font face="Tahoma" size="2">Authorized Liberty 
    Reserve wholesaler! Serve more than 50,000 clients now! We are a registered 
    company in Hong Kong. Operating since 2003. All orders will be processed 
    within 24 hours after receiving the money.(Except public holidays). </font></td>
  </tr>
  </table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber52" height="36">
  <tr>
	<td width="100%" height="30" valign="bottom">
	<p align="right"><b><font face="Tahoma" size="2"><a href="#top">
	Back to Top</a></font></b></td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber53" height="105">
  <tr>
	<td width="100%" height="50">&nbsp;</td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber54">
  <tr>
	<td width="100%" height="30" valign="top"><b>
	<font size="2" face="Tahoma" color="#800000">
	<a name="South Korea">South Korea</a></font></b></td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse" bordercolor="#808080" width="600" id="AutoNumber55">
  <tr>
	<td width="16%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Company</b></font></td>
	<td width="16%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Added</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Payment</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Supported</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>GDCA</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Notes</b></font></td>
  </tr>
  <tr>
	<td width="16%" valign="top">
    <a target="_blank" href="http://www.cyberex.jp/">
    <img border="0" src="http://e-globalcash.net/banners/cebanner125x100.gif" alt="Cyber Exchange Service Japan" width="125" height="100"></a></td>
	<td width="16%" valign="top"><span lang="ja"><font face="Tahoma" size="2">07</font></span><font size="2" face="Tahoma">.0<span lang="ja">5</span>.20<span lang="ja">10</span></font></td>
	<td width="17%" valign="top"><font size="2" face="Tahoma">Visa, Mastercard, 
    Wire transfer, Western Union, PayPal, Local deposits in Japan</font></td>
	<td width="17%" valign="top">
    <p align="center"><span lang="ja"><font size="2" face="Tahoma">English <br>
    Korean</font></span></td>
	<td width="17%" valign="top">
    <p align="center"><span lang="ja"><font size="2" face="Tahoma">Yes</font></span></td>
	<td width="17%" valign="top"><font size="2" face="Tahoma">We provide major 
    e-currency exchange service (Buy, Sell, and swap e-currency services. all 
    Buy, Sell, swap e-currency available).</font></td>
  </tr>
  <tr>
	<td width="16%" valign="top">
    <a href="http://www.exkorea.net/">
    <img border="0" src="../../banners/exkorea.gif" width="190" height="73"></a></td>
	<td width="16%" valign="top">
    <p align="center"><font size="2" face="Tahoma">10.05.20<span lang="ja">1</span>2</font></td>
	<td width="17%" valign="top"><font size="2" face="Tahoma">Visa, Mastercard, 
    Wire transfer, Western Union, PayPal, Local bank deposits in Korea</font></td>
	<td width="17%" valign="top">
    <p align="center"><span lang="ja"><font size="2" face="Tahoma">English <br>
    Korean</font></span></td>
	<td width="17%" valign="top">
    <p align="center"><span lang="ja"><font size="2" face="Tahoma">No</font></span></td>
	<td width="17%" valign="top"><font size="2" face="Tahoma">We provide major 
    e-currency exchange service (Buy, Sell, and swap e-currency services. all 
    Buy, Sell, swap e-currency available).</font></td>
  </tr>
  </table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber56" height="36">
  <tr>
	<td width="100%" height="30" valign="bottom">
	<p align="right"><b><font face="Tahoma" size="2"><a href="#top">
	Back to Top</a></font></b></td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber57" height="105">
  <tr>
	<td width="100%" height="50">&nbsp;</td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber58">
  <tr>
	<td width="100%" height="30" valign="top"><b>
	<font size="2" face="Tahoma" color="#800000">
	<a name="Singapore">Singapore</a></font></b></td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse" bordercolor="#808080" width="600" id="AutoNumber59">
  <tr>
	<td width="16%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Company</b></font></td>
	<td width="16%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Added</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Payment</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Supported</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>GDCA</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Notes</b></font></td>
  </tr>
  <tr>
	<td width="16%" valign="top">
    <font size="2" face="Tahoma">
    <a target="_blank" href="http://asianagold.com/">
    <img border="0" src="http://e-globalcash.net/banners/asiadragon_large.jpg" width="170" height="97"></a></font></td>
	<td width="16%" valign="top"><font size="2" face="Tahoma">2/17/2009 12:00:00 
    AM</font></td>
	<td width="17%" valign="top"><font size="2" face="Tahoma">Wire transfer, 
    Western Union</font></td>
	<td width="17%" valign="top">
    <p align="center"><font size="2" face="Tahoma">English</font></td>
	<td width="17%" valign="top">
    <p align="center"><span lang="ja"><font size="2" face="Tahoma">Yes</font></span></td>
	<td width="17%" valign="top"><font size="2" face="Tahoma">Digital currency 
    exchanger serving Malaysia, Philippines, and Singapore.</font></td>
  </tr>
  <tr>
	<td width="16%" valign="top">&nbsp;</td>
	<td width="16%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
  </tr>
  <tr>
	<td width="16%" valign="top">&nbsp;</td>
	<td width="16%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber60" height="36">
  <tr>
	<td width="100%" height="30" valign="bottom">
	<p align="right"><b><font face="Tahoma" size="2"><a href="#top">
	Back to Top</a></font></b></td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber61" height="105">
  <tr>
	<td width="100%" height="50">&nbsp;</td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber62">
  <tr>
	<td width="100%" height="30" valign="top"><b>
	<font size="2" face="Tahoma" color="#800000"><a name="China">
	China</a></font></b></td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse" bordercolor="#808080" width="600" id="AutoNumber63">
  <tr>
	<td width="16%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Company</b></font></td>
	<td width="16%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Added</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Payment</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Supported</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>GDCA</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Notes</b></font></td>
  </tr>
  <tr>
	<td width="16%" valign="top">
    <font size="2" face="Tahoma"><a target="_blank" href="http://ebuygold.com/">Ebuygold.com</a></font></td>
	<td width="16%" valign="top">
    <p align="center"><font face="Tahoma" size="2">Mar 2008</font></td>
	<td width="17%" valign="top"><font face="Tahoma" size="2">Bank Wire, Western 
    Union. </font></td>
	<td width="17%" valign="top">
    <p align="center"><font face="Tahoma" size="2">English, Chinese</font></td>
	<td width="17%" valign="top">
    <p align="center"><font face="Tahoma" size="2">No</font></td>
	<td width="17%" valign="top"><font face="Tahoma" size="2">Authorized Liberty 
    Reserve wholesaler! Serve more than 50,000 clients now! We are a registered 
    company in Hong Kong. Operating since 2003. All orders will be processed 
    within 24 hours after receiving the money.(Except public holidays). </font></td>
  </tr>
  </table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber64" height="36">
  <tr>
	<td width="100%" height="30" valign="bottom">
	<p align="right"><b><font face="Tahoma" size="2"><a href="#top">
	Back to Top</a></font></b></td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber65" height="105">
  <tr>
	<td width="100%" height="50">&nbsp;</td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber66">
  <tr>
	<td width="100%" height="30" valign="top"><b>
	<font size="2" face="Tahoma" color="#800000"><a name="Japan">
	Japan</a></font></b></td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse" bordercolor="#808080" width="600" id="AutoNumber67">
  <tr>
	<td width="16%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Company</b></font></td>
	<td width="16%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Added</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Payment</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Supported</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>GDCA</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Notes</b></font></td>
  </tr>
  <tr>
	<td width="16%" valign="top">
    <a target="_blank" href="http://www.cyberex.jp/">
    <img border="0" src="http://e-globalcash.net/banners/cebanner125x100.gif" alt="Cyber Exchange Service Japan" width="125" height="100"></a></td>
	<td width="16%" valign="top">
    <p align="center"><span lang="ja"><font face="Tahoma" size="2">07</font></span><font size="2" face="Tahoma">.0<span lang="ja">5</span>.20<span lang="ja">10</span></font></td>
	<td width="17%" valign="top"><font size="2" face="Tahoma">Visa, Mastercard, 
    Wire transfer, Western Union, PayPal, Local deposits in Japan</font></td>
	<td width="17%" valign="top">
    <p align="center"><span lang="ja"><font size="2" face="Tahoma">English <br>
    Japanese</font></span></td>
	<td width="17%" valign="top">
    <p align="center"><span lang="ja"><font size="2" face="Tahoma">Yes</font></span></td>
	<td width="17%" valign="top"><font size="2" face="Tahoma">We provide major 
    e-currency exchange service (Buy, Sell, and swap e-currency services. all 
    Buy, Sell, swap e-currency available).</font></td>
  </tr>
  <tr>
	<td width="16%" valign="top">
    <a target="_blank" href="http://www.exgold.jp/">
    <img border="0" src="../../banners/e-goldex.gif" width="135" height="40"></a></td>
	<td width="16%" valign="top">
    <p align="center"><span lang="ja"><font face="Tahoma" size="2">07</font></span><font size="2" face="Tahoma">.0<span lang="ja">5</span>.20<span lang="ja">10</span></font></td>
	<td width="17%" valign="top"><font face="Tahoma" size="2">Domestic bank 
    deposit in Japan</font></td>
	<td width="17%" valign="top">
    <p align="center"><span lang="ja"><font size="2" face="Tahoma">Japanese</font></span></td>
	<td width="17%" valign="top">
    <p align="center"><span lang="ja"><font size="2" face="Tahoma">Yes</font></span></td>
	<td width="17%" valign="top">&nbsp;</td>
  </tr>
  </table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber68" height="36">
  <tr>
	<td width="100%" height="30" valign="bottom">
	<p align="right"><b><font face="Tahoma" size="2"><a href="#top">
	Back to Top</a></font></b></td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber69" height="105">
  <tr>
	<td width="100%" height="50">&nbsp;</td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber70">
  <tr>
	<td width="100%" height="30" valign="top"><b>
	<font size="2" face="Tahoma" color="#800000">
	<a name="Indonesia">Indonesia</a></font></b></td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse" bordercolor="#808080" width="600" id="AutoNumber71">
  <tr>
	<td width="16%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Company</b></font></td>
	<td width="16%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Added</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Payment</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Supported</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>GDCA</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Notes</b></font></td>
  </tr>
  <tr>
	<td width="16%" valign="top"><a href="https://www.goldmediator.com/">
    <img border="0" src="http://www.e-globalcash.net/banners/logo-gm.jpg" width="151" height="124"></a></td>
	<td width="16%" valign="top">
    <p align="center"><font face="Tahoma" size="2">07.17.2010</font></td>
	<td width="17%" valign="top"><font size="2" face="Tahoma">Wire transfer</font></td>
	<td width="17%" valign="top"><font size="2" face="Tahoma">English, 
    Indonesian</font></td>
	<td width="17%" valign="top">
    <p align="center"><span lang="ja"><font size="2" face="Tahoma">Yes</font></span></td>
	<td width="17%" valign="top"><font size="2" face="Tahoma">Indonesian 
    exchanger, since 2005, serving Liberty Reserve, Euro Gold Cash, Digital Gold 
    Pay, C-gold and Gift Certificate (Betonmarkets).</font></td>
  </tr>
  </table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber72" height="36">
  <tr>
	<td width="100%" height="30" valign="bottom">
	<p align="right"><b><font face="Tahoma" size="2"><a href="#top">
	Back to Top</a></font></b></td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber73" height="105">
  <tr>
	<td width="100%" height="50">&nbsp;</td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber74">
  <tr>
	<td width="100%" height="30" valign="top"><b>
	<font size="2" face="Tahoma" color="#800000"><a name="Thailand">
	Thailand</a></font></b></td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse" bordercolor="#808080" width="600" id="AutoNumber75">
  <tr>
	<td width="16%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Company</b></font></td>
	<td width="16%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Added</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Payment</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Supported</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>GDCA</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Notes</b></font></td>
  </tr>
  <tr>
	<td width="16%" valign="top">&nbsp;</td>
	<td width="16%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
  </tr>
  <tr>
	<td width="16%" valign="top">&nbsp;</td>
	<td width="16%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
  </tr>
  <tr>
	<td width="16%" valign="top">&nbsp;</td>
	<td width="16%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber76" height="36">
  <tr>
	<td width="100%" height="30" valign="bottom">
	<p align="right"><b><font face="Tahoma" size="2"><a href="#top">
	Back to Top</a></font></b></td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber77" height="105">
  <tr>
	<td width="100%" height="50">&nbsp;</td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber78">
  <tr>
	<td width="100%" height="30" valign="top"><b>
	<font size="2" face="Tahoma" color="#800000"><a name="UAE">UAE</a></font></b></td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse" bordercolor="#808080" width="600" id="AutoNumber79">
  <tr>
	<td width="16%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Company</b></font></td>
	<td width="16%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Added</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Payment</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Supported</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>GDCA</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Notes</b></font></td>
  </tr>
  <tr>
	<td width="16%" valign="top">&nbsp;</td>
	<td width="16%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
  </tr>
  <tr>
	<td width="16%" valign="top">&nbsp;</td>
	<td width="16%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
  </tr>
  <tr>
	<td width="16%" valign="top">&nbsp;</td>
	<td width="16%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber80" height="36">
  <tr>
	<td width="100%" height="30" valign="bottom">
	<p align="right"><b><font face="Tahoma" size="2"><a href="#top">
	Back to Top</a></font></b></td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber81" height="105">
  <tr>
	<td width="100%" height="50">&nbsp;</td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber82">
  <tr>
	<td width="100%" height="30" valign="top"><b>
	<font size="2" face="Tahoma" color="#800000">
	<a name="Saudi Arabia">Saudi Arabia</a></font></b></td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse" bordercolor="#808080" width="600" id="AutoNumber83">
  <tr>
	<td width="16%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Company</b></font></td>
	<td width="16%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Added</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Payment</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Supported</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>GDCA</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Notes</b></font></td>
  </tr>
  <tr>
	<td width="16%" valign="top">&nbsp;</td>
	<td width="16%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
  </tr>
  <tr>
	<td width="16%" valign="top">&nbsp;</td>
	<td width="16%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
  </tr>
  <tr>
	<td width="16%" valign="top">&nbsp;</td>
	<td width="16%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber84" height="36">
  <tr>
	<td width="100%" height="30" valign="bottom">
	<p align="right"><b><font face="Tahoma" size="2"><a href="#top">
	Back to Top</a></font></b></td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber85" height="105">
  <tr>
	<td width="100%" height="50">&nbsp;</td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber86">
  <tr>
	<td width="100%" height="30" valign="top"><b>
	<font size="2" face="Tahoma" color="#800000"><a name="India">
	India</a></font></b></td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse" bordercolor="#808080" width="600" id="AutoNumber87">
  <tr>
	<td width="16%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Company</b></font></td>
	<td width="16%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Added</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Payment</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Supported</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>GDCA</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Notes</b></font></td>
  </tr>
  <tr>
	<td width="16%" valign="top">&nbsp;</td>
	<td width="16%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
  </tr>
  <tr>
	<td width="16%" valign="top">&nbsp;</td>
	<td width="16%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
  </tr>
  <tr>
	<td width="16%" valign="top">&nbsp;</td>
	<td width="16%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber88" height="36">
  <tr>
	<td width="100%" height="30" valign="bottom">
	<p align="right"><b><font face="Tahoma" size="2"><a href="#top">
	Back to Top</a></font></b></td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber89" height="105">
  <tr>
	<td width="100%" height="50">&nbsp;</td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber90">
  <tr>
	<td width="100%" height="30" valign="top"><b>
	<font size="2" face="Tahoma" color="#800000"><a name="Nigeria">
	Nigeria</a></font></b></td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse" bordercolor="#808080" width="600" id="AutoNumber91">
  <tr>
	<td width="16%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Company</b></font></td>
	<td width="16%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Added</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Payment</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Supported</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>GDCA</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Notes</b></font></td>
  </tr>
  <tr>
	<td width="16%" valign="top">
    <p align="center"><font size="2" face="Tahoma">
    <a target="_blank" href="http://www.winkpayment.com/">WinkPayment</a></font></td>
	<td width="16%" valign="top">
    <p align="center"><font size="2" face="Tahoma">05.09.2010</font></td>
	<td width="17%" valign="top"><font size="2" face="Tahoma">Bank Wire, Local 
    deposit in Malaysia and Nigeria Banks.</font></td>
	<td width="17%" valign="top">
    <p align="center"><font size="2" face="Tahoma">English</font></td>
	<td width="17%" valign="top">
    <p align="center"><font size="2" face="Tahoma">No</font></td>
	<td width="17%" valign="top"><font size="2" face="Tahoma">We offer fast, 
    simple and reliable services. We provide service for buy/sell or exchanges 
    of major e-currencies such as Euro Gold cash and other digital currency. We 
    also offer Money transfer service from Nigeria to Malaysia and vice versa.
    </font></td>
  </tr>
  <tr>
	<td width="16%" valign="top"><font size="2" face="Tahoma">
    <a target="_blank" href="http://instantgoldng.com/l">
    InstantGoldNG.com</a></font></td>
	<td width="16%" valign="top"><font size="2" face="Tahoma">Aug 2009</font></td>
	<td width="17%" valign="top"><font size="2" face="Tahoma">Naira (Nigeria 
    Bank Deposit), Nigeria Debit card, USD (Nigeria Bank Deposit) &amp; Bank wire</font></td>
	<td width="17%" valign="top"><font size="2" face="Tahoma">English, Arabic, 
    African Languages (Yoruba, Igbo &amp; Ahusa)</font></td>
	<td width="17%" valign="top">
    <p align="center"><font size="2" face="Tahoma">No</font></td>
	<td width="17%" valign="top"><font size="2" face="Tahoma">Instant Gold 
    Nigeria is the Africa&#39;s strongest Liberty Reserve exchanger in terms of 
    finance. Has offices in all the west Africa countries including the 
    middle-East, Dubai. Sell at the Cheapest price in the continent, Ease of 
    withdrawal &amp; high purchasing power, Instant funding, SMS and Email alert 
    after funding, Safety of customers funds and unbeatable customer support by 
    our dedicated staffs. </font></td>
  </tr>
  <tr>
	<td width="16%" valign="top">&nbsp;</td>
	<td width="16%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber92" height="36">
  <tr>
	<td width="100%" height="30" valign="bottom">
	<p align="right"><b><font face="Tahoma" size="2"><a href="#top">
	Back to Top</a></font></b></td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber93" height="105">
  <tr>
	<td width="100%" height="50">&nbsp;</td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber94">
  <tr>
	<td width="100%" height="30" valign="top"><b>
	<font size="2" face="Tahoma" color="#800000"><a name="Senegal">
	Senegal</a></font></b></td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse" bordercolor="#808080" width="600" id="AutoNumber95">
  <tr>
	<td width="16%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Company</b></font></td>
	<td width="16%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Added</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Payment</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Supported</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>GDCA</b></font></td>
	<td width="17%" bgcolor="#333333" align="center" height="25">
	<font color="#FFFFFF" face="Tahoma" size="2"><b>Notes</b></font></td>
  </tr>
  <tr>
	<td width="16%" valign="top">&nbsp;</td>
	<td width="16%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
  </tr>
  <tr>
	<td width="16%" valign="top">&nbsp;</td>
	<td width="16%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
  </tr>
  <tr>
	<td width="16%" valign="top">&nbsp;</td>
	<td width="16%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
	<td width="17%" valign="top">&nbsp;</td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber96" height="36">
  <tr>
	<td width="100%" height="30" valign="bottom">
	<p align="right"><b><font face="Tahoma" size="2"><a href="#top">
	Back to Top</a></font></b></td>
  </tr>
</table>
</center>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber97" height="105">
  <tr>
	<td width="100%" height="50">&nbsp;</td>
  </tr>
</table>
</center>
</div>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber14">
<tr>
  <td width="100%">&nbsp;</td>
</tr>
</table>