<?php
$langs	=	array ('HEADING_TITLE'	=>	'Email Templates',
					'HEADING_NEW_EMAILTEMPLATE'	=>	'New Email Template',
					'HEADING_EDIT_EMAILTEMPLATE'	=>	'Edit Email Template',
					'TEXT_SELECT_EMAILTEMPLATE'	=>	'Select Partent Email Template:',
					'TABLE_HEADING_EMAILTEMPLATE_NAME'	=> 'Email Template Name',
					'TABLE_HREADING_EMAILTEMPLATE_STATUS'	=> 'Email Template Status',
					'TABLE_HREADING_EMAILTEMPLATE_SORT_ORDER'	=>	'Sort Order',						
					'LINK_NEW_EMAILTEMPLATE'	=>	'Add Email Template',
					'TEXT_EMAILTEMPLATE_TITLE'	=> 	'Email Template Title:',
					'TEXT_EMAILTEMPLATE_SUBJECT'	=>	'Email Template Subject:',
					'TEXT_EMAILTEMPLATE_KEY'	=>	'Email Template Key:',
					'TEXT_EMAILTEMPLATE_STATUS'	=>	'Status:',
					'TEXT_EMAILTEMPLATE_CONTENT'	=> 'Email Template Content:',
					'TEXT_EMAILTEMPLATE_USAGE'	=>	'Usage Help:',
					'TEXT_EMAILTEMPLATE_IS_HTML_EMAIL'	=> 'is Html Email?:',
					'TEXT_DELETE_CONFIRM_MESSAGE'	=>	'Are you sure you want to delete the Email Template?',		
					
			);
			
define('TEXT_MESSAGE_EMAILTEMPLATES_DELETED', 'The category have been removed.');
			
?>