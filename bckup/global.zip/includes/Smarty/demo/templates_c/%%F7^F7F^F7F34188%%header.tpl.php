<?php /* Smarty version 2.6.18, created on 2012-03-15 05:50:24
         compiled from header.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'popup_init', 'header.tpl', 3, false),)), $this); ?>
<HTML>
<HEAD>
<?php echo smarty_function_popup_init(array('src' => "/javascripts/overlib.js"), $this);?>

<TITLE><?php echo $this->_tpl_vars['title']; ?>
 - <?php echo $this->_tpl_vars['Name']; ?>
</TITLE>
</HEAD>
<BODY bgcolor="#ffffff">