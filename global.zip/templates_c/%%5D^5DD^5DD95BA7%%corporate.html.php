<?php /* Smarty version 2.6.18, created on 2012-03-05 02:56:39
         compiled from home/corporate.html */ ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<div align="right">
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="650" id="AutoNumber35">
<tr>
<td width="100%" height="20">&nbsp;</td>
</tr>
<tr>
<td width="100%" height="50" valign="top">
	<font face="Tahoma" size="3" color="#800000"><b>Cooperate 
Information</b>
	</font></td>
</tr>
<tr>
<td width="100%" valign="top">
<blockquote>
  <p align="left">
  <font size="2" face="Tahoma">e-Globalcash (e-Global Cash Network Ltd) would like to welcome everyone to the future of 
  electronic currency industry. In 2009 we have finally finished 
  our expansion and transition to a state of the art, highly 
  secure building, which allows our employees to provide even 
  better service for you. We have worked very hard to complete 
  this transition with no interruptions to our service. </font>
  </p>
</blockquote>
</td>
</tr>
</table>
  </div>