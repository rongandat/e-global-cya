<form action="http://egcash.cyahost.com/index.php?page=sci" method="POST">
        <input type="hidden" name="payee_account" value="9073297">
        <input type="hidden" name="payer_account" value="">
        <input type="hidden" name="checkout_amount" value="10">
        <input type="hidden" name="checkout_currency" value="USD">
        <input type="hidden" name="cancel_url" value="http://egcash.cyahost.com/cancel.php">
        <input type="hidden" name="fail_url" value="http://egcash.cyahost.com/fail.php">
        <input type="hidden" name="success_url" value="http://egcash.cyahost.com/success.php">
        <input type="hidden" name="status_url" value="http://egcash.cyahost.com/status.php">
        <input type="hidden" name="status_method" value="GET">
        <input type="hidden" name="action" value="process">
        <input type="hidden" name="fsdfs" value="fsdfsd">
        <input type="hidden" name="fsfs" value="gdfg">
        <input type="hidden" name="gdgd" value="gdgd">
        <input type="submit" />
</form>
