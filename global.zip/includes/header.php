<?php
	echo $smarty->fetch('header.html');
?>