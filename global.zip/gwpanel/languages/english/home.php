<?php

// LOGIN PAGE LANGUAGES	///////////////////////////

	$smarty->assign('TEXT_LOGIN_NOTICE','Please login to access the admin panel');
	$smarty->assign('LABEL_USERNAME','User Name ');
	$smarty->assign('LABEL_PASSWORD','Password ');
	
	$smarty->assign('LABEL_ACCESS_ADMIN_PANEL','Access Admin Panel');
	
	define('ERROR_INVALID_ACCOUNT','Avalid Account Access');
	
	$smarty->assign('LABEL_REMEMBER_ME','Remember Me');
	$smarty->assign('TEXT_LOGOUT_SUCCESS','You have been successfull logout');
	
// eof - LOGIN PAGE

?>