<?php
$langs	=	array('HEADING_TITLE'=> 'Languages',
				'HEADING_NEW_LANGUAGE'	=>	'Add New Language',
				'LINK_NEW_LANGUAGE'		=> 'Add Language',
				'HEADING_EDITLANGUAGE'	=>	'Edit Language',
				'HEADER_LANGUAGE_NAME'	=>	'Language Name',
				'HEADER_LANGUAGE_CODE'	=> 	'Language Code',
				'HEADER_LANGUAGE_STATUS'	=> 'Status',
				'HEADER_LANGUAGE_IMAGE'	=> 'Icon',
				'TEXT_INACTIVE'	=>	'Inactive',
				'TEXT_ACTIVE'	=>	'Active',
				'HEADING_EDIT_TITLE'	=> 	'Edit Language',
				'TEXT_LANGUAGE_NAME'	=>	'Language Name:',
				'TEXT_LANGUAGE_CODE'	=>	'Language Code:',
				'TEXT_LANGUAGE_DIRECTORY'	=>	'Language Directory:',
				'TEXT_LANGUAGE_IMAGE'	=>	'Language Icon:',
				'TEXT_LANGUAGE_STATUS'	=> 	'Status:',
				'TEXT_LANGUAGE_SORT_ORDER'	=> 	'Sort Order:',
				'TEXT_DELETE_CONFIRM_MESSAGE'	=>	'Are you sure you want to delete the language?'
			);
		
define('TEXT_MESSAGE_LANGUAGE_DELETED','The language have been deleted.');		
?>