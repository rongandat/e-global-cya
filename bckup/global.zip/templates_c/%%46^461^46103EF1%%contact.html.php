<?php /* Smarty version 2.6.18, created on 2012-03-29 05:32:57
         compiled from home/contact.html */ ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<div align="right">
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="650" id="AutoNumber35">
  <tr>
	<td width="100%" height="20">&nbsp;</td>
  </tr>
  <tr>
	<td width="100%" height="50" valign="top">
		<font face="Tahoma" size="3" color="#800000"><b>Contact Us</b>
		</font></td>
  </tr>
  <tr>
	<td width="100%" height="25" valign="top">
		<blockquote>
          <p><b><font face="Tahoma" size="2">Use a form of contact to submit 
          this forms <font color="#FF0000">* Marks 
                  must fill in</font></font></b></p>
        </blockquote>
    </td>
  </tr>
  <tr>
	<td width="100%" valign="top">
	<form method="POST" action="https://e-globalcash.net/contact.php">
      <div align="center">
        <center>
        <table border="0" cellpadding="5" cellspacing="1" width="531" id="AutoNumber36">
          <tr>
            <td width="186"> <font color="#FF0000"><b><font face="Tahoma" size="2">
            * </font></b></font>
		<font size="2" face="Tahoma">Your Name:</font></td>
            <td width="322"><font face="Tahoma">
		<input style="WIDTH: 200px" id="ctl00_cp1_tbName0" class="form" name="Name" AUTOCOMPLETE="OFF" size="20"></font></td>
          </tr>
          <tr>
            <td width="186"> <font color="#FF0000"><b><font face="Tahoma" size="2">
            * </font></b></font><font size="2" face="Tahoma">
		Your E-mail Address:</font></td>
            <td width="322"><font face="Tahoma">
		<input style="WIDTH: 200px" id="ctl00_cp1_tbEmail0" class="form" name="email" AUTOCOMPLETE="OFF" size="20"></font></td>
          </tr>
          <tr>
            <td width="186"> <font color="#FF0000"><b><font face="Tahoma" size="2">
            * </font></b></font><font size="2" face="Tahoma">
		Select Department:</font></td>
            <td width="322"><font face="Tahoma">
		<select style="WIDTH: 200px" id="ctl00_cp1_dlCateg0" name="ctl00$cp1$dlCateg">
		<option selected value="General Questions">General Questions
		</option>
		<option value="Funding Questions">Funding Questions</option>
		<option value="Password/PIN/Key/Email Reset">
		Password/PIN/Key/Email Reset</option>
		<option value="API/SCI and Technical Questions">API/SCI and 
		Technical Questions</option>
		<option value="Business Department">Business Department
		</option>
		<option value="Abuse Department">Abuse Department</option>
		</select></font></td>
          </tr>
          <tr>
            <td width="186"><font size="2" face="Tahoma">
		Your Account #:</font></td>
            <td width="322"><font face="Tahoma">
		<input style="WIDTH: 200px" id="ctl00_cp1_tbAccount0" class="form" name="Account" size="20"></font></td>
          </tr>
          <tr>
            <td width="186"> <font color="#FF0000"><b><font face="Tahoma" size="2">
            * </font></b></font><font size="2" face="Tahoma">
		Subject:</font></td>
            <td width="322"><font face="Tahoma">
		<input style="WIDTH: 200px" id="ctl00_cp1_tbSubject0" class="form" name="Subject" size="20"></font></td>
          </tr>
          <tr>
            <td width="186" valign="top"> <font color="#FF0000"><b><font face="Tahoma" size="2">
            * </font></b></font>
		<font size="2" face="Tahoma">Question/Comment:</font></td>
            <td width="322" valign="top"><font face="Tahoma">
		<textarea style="WIDTH: 355px; HEIGHT: 126px" id="ctl00_cp1_tbBody" class="form" name="Comment" rows="1" cols="20"></textarea></font></td>
          </tr>
        </table>
        </center>
      </div>
      <p align="center"><input type="submit" value="Submit Message" name="B1"><input type="reset" value="Reset" name="B2"></p>
    </form>
    </td>
  </tr>
  <tr>
	<td width="100%" valign="top">
	&nbsp;</td>
  </tr>
  <tr>
	<td width="100%" valign="top">
	&nbsp;</td>
  </tr>
</table>
</div>