<?php
define('TEXT_CUSTOM_QUESTION','Custom Question');
define('ERROR_EMAIL_CONFIRM_EMAIL_MATCH','E-mail and Confirm E-mail must be the same.');
define('ERROR_INVALID_ACCOUNT','Invalid Account Number/Password.');
define('ERROR_INVALID_ACCOUNT_SCI','Invalid Account Number.');

$langs['signup']	=	array('SIGNUP_PAGE_HEADING'=>'Registration: Part 1 of 2');
?>