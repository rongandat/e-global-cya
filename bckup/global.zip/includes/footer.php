<div align="center">
  <center>
  <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="750" id="AutoNumber6" height="34">
    <tr>
      <td width="100%" height="34">
      <p align="center"><font face="Arial" size="2" color="#FFFFFF">
      <span lang="ja">Corporate | Terms of Service | Privacy Policy | Anti - 
      money Laundering Policy | Contact us</span></font></td>
    </tr>
  </table>
  </center>
</div>
