<?php /* Smarty version 2.6.18, created on 2010-02-28 18:52:06
         compiled from home/applications.html */ ?>
<div align="right">
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="650" id="AutoNumber35" height="286">
	  <tr>
	<td width="100%" height="20">&nbsp;</td>
	</tr>
	<tr>
	<td width="100%" height="70" valign="top">
		<font face="Tahoma" size="3" color="#800000"><b>SCI, API 
	Guide</b>
		</font></td>
	</tr>
	<tr>
	<td width="100%" valign="top" height="4">
	<blockquote>
	  <b><font size="2" face="Tahoma">Version Last Update Download</font></b></blockquote>
	</td>
	</tr>
	<tr>
	<td width="100%" valign="top" height="4">
	<blockquote>
	  <blockquote>
		<p><font face="Tahoma" size="2">SCI: SCI Guide (Coming 
		soon!)</font></p>
	  </blockquote>
	</blockquote>
	</td>
	</tr>
	<tr>
	<td width="100%" valign="top" height="4">
	<blockquote>
	  <blockquote>
		<p><font face="Tahoma" size="2">API: API Guide (Coming 
		soon!)</font></p>
	  </blockquote>
	</blockquote>
	</td>
	</tr>
	<tr>
	<td width="100%" valign="top" height="200">&nbsp;</td>
	</tr>
</table>
</div>