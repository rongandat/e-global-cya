<?php /* Smarty version 2.6.18, created on 2012-03-15 05:50:24
         compiled from footer.tpl */ ?>
</BODY>
</HTML>