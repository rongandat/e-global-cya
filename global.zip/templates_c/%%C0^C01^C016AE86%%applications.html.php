<?php /* Smarty version 2.6.18, created on 2013-06-27 10:41:39
         compiled from home/applications.html */ ?>
<div align="right">
    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="650" id="AutoNumber35" height="286">
        <tr>
            <td width="100%" height="20">&nbsp;</td>
        </tr>
        <tr>
            <td width="100%" valign="top">
                <font face="Tahoma" size="3" color="#800000"><b>SCI Guide
                </b>
                </font>
            </td>
        </tr>
        <tr>
            <td width="100%" valign="top">
                <blockquote>
                    <blockquote>
                        <a href="<?php echo $this->_tpl_vars['general_form_href']; ?>
"><font color="">General form</font></a>
                    </blockquote>
                </blockquote>
            </td>
        </tr>
        <tr>
            <td width="100%" height="70" valign="top">
                <font face="Tahoma" size="3" color="#800000"><b>API Guide
                </b>
                </font>
            </td>
        </tr>

        <tr>
            <td width="100%" valign="top" height="4">
                <blockquote>
                    <blockquote>
                        <p><font face="Tahoma" size="2">SCI: SCI Guide (Coming 
                            soon!)</font></p>
                    </blockquote>
                </blockquote>
            </td>
        </tr>
        <tr>
            <td width="100%" valign="top" height="4">
                <blockquote>
                    <blockquote>
                        <p><font face="Tahoma" size="2">API: API Guide (Coming 
                            soon!)</font></p>
                    </blockquote>
                </blockquote>
            </td>
        </tr>
        <tr>
            <td width="100%" valign="top" height="200">&nbsp;</td>
        </tr>
    </table>
</div>