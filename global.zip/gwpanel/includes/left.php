<div style="width:180px" >
   <div  align="center">Global Settings</div>
	<ul id="leftMenu">
		<li><a href="<?php echo get_admin_link(PAGE_ADMIN_ACCOUNTS); ?>"><?php echo MNU_ADMIN_ACCOUNTS; ?></a></li>	
		<li><a href="<?php echo get_admin_link(PAGE_SETTINGS); ?>"><?php echo MNU_ADMIN_SETTINGS; ?></a></li>	
		<li><a href="<?php echo get_admin_link(PAGE_LANGUAGES); ?>"><?php echo MNU_ADMIN_LANGUAGES; ?></a></li>			
		<li><a href="<?php echo get_admin_link(PAGE_EMAILTEMPLATES); ?>"><?php echo MNU_ADMIN_EMAILTEMPLATES; ?></a></li>
		<li><a href="<?php echo get_admin_link(PAGE_SECURITY_QUESTIONS); ?>"><?php echo MNU_ADMIN_SECURITY_QUESTIONS; ?></a></li>			
		<li><a href="<?php echo get_admin_link(PAGE_NEWS); ?>"><?php echo MNU_ADMIN_NEWS; ?></a></li>		
		<li><a href="<?php echo get_admin_link(PAGE_FAQS); ?>"><?php echo MNU_ADMIN_FAQS; ?></a></li>		
	</ul>
   </div>	
   <div  align="center">Users</div>
	<ul id="leftMenu">
		<li><a href="<?php echo get_admin_link(PAGE_USERS); ?>"><?php echo MNU_ADMIN_USERS; ?></a></li>	
	</ul>
   </div>	   
   <div  align="center">Payment</div>
	<ul id="leftMenu">
		<li><a href="<?php echo get_admin_link(PAGE_CURRENCIES); ?>"><?php echo MNU_ADMIN_CURRENCIES; ?></a></li>	
		<li><a href="<?php echo get_admin_link(PAGE_ADD_FUNDS); ?>"><?php echo MNU_ADMIN_ADD_FUNDS; ?></a></li>	
		<li><a href="<?php echo get_admin_link(PAGE_TRANSACTIONS); ?>"><?php echo MNU_ADMIN_TRANSACTIONS; ?></a></li>			
	</ul>
   </div>					
</div>