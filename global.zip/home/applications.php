<?php

$smarty->assign('general_form_href', get_href_link(PAGE_GENERAL_FORM));
$_html_main_content = $smarty->fetch('home/applications.html');


?>