<?php	
	// get newest rates	
	
	$_html_main_content = $smarty->fetch('home/index.html');	
?>