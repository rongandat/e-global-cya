<?php
$langs	=	array ('HEADING_TITLE'	=>	'Faqs',
					'HEADING_NEW_FAQ'	=>	'New Faq',
					'HEADING_EDIT_FAQ'	=>	'Edit Faq',
					'TEXT_SELECT_FAQ'	=>	'Select Partent Faq:',
					'TABLE_HEADING_FAQ_NAME'	=> 'Faq Name',
					'TABLE_HREADING_FAQ_STATUS'	=> 'Faq Status',
					'TABLE_HREADING_FAQ_SORT_ORDER'	=>	'Sort Order',						
					'LINK_NEW_FAQ'	=>	'Add Faq',
					'TEXT_FAQ_NAME'	=> 	'Faq Name:',
					'TEXT_FAQ_SORT_ORDER'	=>	'Sort Order:',
					'TEXT_FAQ_STATUS'	=>	'Status:',
					'TEXT_FAQ_DESCRIPTION'	=> 'Faq Description:',
					'TEXT_FAQ_ISTOPIC'	=> 'is Topic?:',
					'TEXT_DELETE_CONFIRM_MESSAGE'	=>	'Are you sure you want to delete the Faq?',		
					
			);
			
define('TEXT_MESSAGE_FAQS_DELETED', 'The category have been removed.');
			
?>