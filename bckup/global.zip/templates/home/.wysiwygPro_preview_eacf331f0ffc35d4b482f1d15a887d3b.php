<?php
if ($_GET['randomId'] != "1ZgwLJlk6Jbpkr5nM358XfuPPW_MWHq3VUINNqBwmyeUmTbG_2JgZJ5_RXCSglGR") {
    echo "Access Denied";
    exit();
}

// display the HTML code:
echo stripslashes($_POST['wproPreviewHTML']);

?>  
