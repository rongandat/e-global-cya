<?php
define('ERROR_FIELD_UPLOAD','Image Upload Error#:');
define('TEXT_MESSAGE_ITEM_DELETED','The item have been deleted.');

$langs	=	array('HEADING_TITLE'	=>	'Items',
				'LINK_NEW_ITEM'	=>	'New Item',
				'HEADING_NEW_ITEM'	=>	'Add New Item',
				'HEADING_EDIT_ITEM'	=>	'Edit Item',				
				'HEADER_ITEM_NAME'	=> 'Item Name',
				'HEADER_ITEM_STATUS'	=>	'Status',
				'HEADER_ITEM_CATEGORY'	=>	'Category',
				'HEADER_ITEM_SORT_ORDER'	=>	'Sort Order',
				'TEXT_ITEM_NAME'	=> 'Item Name:',
				'TEXT_ITEM_DESCRIPTION'	=> 'Item Description:',
				'TEXT_ITEM_STATUS'	=> 'Item Status:',
				'TEXT_ITEM_IMAGE'	=> 'Item Image:',
				'TEXT_ITEM_SORT_ORDER'	=> ' Sort Order:',
				'TEXT_ITEM_SHORT_DESC'	=>	'Short Description:',
				'TEXT_ITEM_CATEGORY'	=>	'Category:',				
				
				'TEXT_DELETE_CONFIRM_MESSAGE'	=>	'Are you sure you want to delete the items?',									
				
		)
?>