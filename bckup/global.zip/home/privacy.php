<?php
	$_html_main_content = $smarty->fetch('home/privacy.html');
?>