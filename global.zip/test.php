<form action="http://global.lc/index.php?page=sci" method="POST">
        <input type="hidden" name="payee_account" value="9073297">
        <input type="hidden" name="payer_account" value="">
        <input type="hidden" name="checkout_amount" value="20">
        <input type="hidden" name="checkout_currency" value="USD">
        <input type="hidden" name="cancel_url" value="http://global.lc/cancel.php">
        <input type="hidden" name="fail_url" value="http://zodia.lc/fail.php">
        <input type="hidden" name="success_url" value="http://zodia.lc/success.php">
        <input type="hidden" name="status_url" value="http://zodia.lc/status.php">
        <input type="hidden" name="status_method" value="POST">
        <input type="hidden" name="action" value="process">
        <input type="hidden" name="" value="">
        <input type="submit" />
</form>