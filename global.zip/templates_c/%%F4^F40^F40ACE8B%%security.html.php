<?php /* Smarty version 2.6.18, created on 2012-06-03 06:04:23
         compiled from home/security.html */ ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<div align="right">
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="650" id="AutoNumber35" height="713">
<tr>
<td width="100%" height="20">&nbsp;</td>
</tr>
<tr>
<td width="100%" height="70" valign="top">
	<font face="Tahoma" size="3" color="#800000"><b>Security 
Measures</b>
	</font></td>
</tr>
<tr>
<td width="100%" valign="top" height="35">
<blockquote>
  <p align="left"><b><font size="2" face="Tahoma">What is a 
  fraudulent email? </font></b></p>
</blockquote>
</td>
</tr>
<tr>
<td width="100%" valign="top" height="67">
<blockquote>
  <p align="left"><font size="2" face="Tahoma">A fraudulent 
  (spoof) email pretends to be from a well-known company in an 
  attempt to get personal information from you. People who send 
  spoof emails hope to use your information  such as credit and 
  debit card numbers or account passwords  to commit identity 
  theft. </font></p>
</blockquote>
</td>
</tr>
<tr>
<td width="100%" valign="top" height="35">
<blockquote>
  <p align="left"><font size="2" face="Tahoma"><b>You can 
  prevent spoof from affecting you </b></font></p>
</blockquote>
</td>
</tr>
<tr>
<td width="100%" valign="top" height="67">
<blockquote>
  <p align="left"><font size="2" face="Tahoma">Spoof or phishing 
  emails and the spoof websites often associated with them are 
  deceptive in appearance. However, they contain content that 
  reveals that they are fake. The most important thing to do to 
  protect yourself is to be able to spot this misleading 
  content: </font></p>
</blockquote>
</td>
</tr>
<tr>
<td width="100%" valign="top" height="35">
<blockquote>
  <p align="left"><font size="2" face="Tahoma"><b>What to watch 
  out for </b></font></p>
</blockquote>
</td>
</tr>
<tr>
<td width="100%" valign="top" height="163">
<blockquote>
  <p align="left"><font size="2" face="Tahoma">Generic 
  greetings. Many spoof emails begin with a general greeting, 
  such as: &quot;Dear Global Cash member.&quot; <br>
  A false sense of urgency. Most spoof emails try to deceive you 
  with the threat that your account is in jeopardy if you don&#39;t 
  update it ASAP. <br>
  Fake links. The text in a link looks valid, but then sends you 
  to a spoof address. Always check where a link is going before 
  you click. Move your mouse over it and look at the URL in your 
  browser or email status bar. If the link looks suspicious, do 
  not click on it, and be aware that a fake link may even have 
  the text &quot;Global Cash&quot; in it. If you are not sure about an 
  email, forward the suspicious email to  Global Cash support 
  for analysis. </font></p>
</blockquote>
</td>
</tr>
<tr>
<td width="100%" valign="top" height="34">
<blockquote>
  <p align="left"><b><font size="2" face="Tahoma">Questions e-Global Cash will never ask you in an email </font></b></p>
</blockquote>
</td>
</tr>
<tr>
<td width="100%" valign="top" height="51">
<blockquote>
  <p><font size="2" face="Tahoma">To help you better identify 
  fake emails, we follow strict rules. We will never ask for the 
  following personal information in emails: </font></p>
</blockquote>
</td>
</tr>
<tr>
<td width="100%" valign="top" height="58">
<blockquote>
  <ul>
	<li>
	<p align="left"><font size="2" face="Tahoma">Credit and 
	debit card numbers; </font></li>
	<li>
	<p align="left"><font size="2" face="Tahoma">Bank account 
	numbers; </font></li>
	<li>
	<p align="left"><font size="2" face="Tahoma">Driver&#39;s 
	License numbers; </font></li>
	<li>
	<p align="left"><font size="2" face="Tahoma">Email 
	addresses; </font></li>
	<li>
	<p align="left"><font size="2" face="Tahoma">Passwords;
	</font></li>
	<li>
	<p align="left"><font size="2" face="Tahoma">Your full name.
	</font></li>
  </ul>
</blockquote>
</td>
</tr>
<tr>
<td width="100%" valign="top" height="57">
&nbsp;</td>
</tr>
</table>
</div>