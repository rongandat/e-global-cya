<?php
echo $_GET['error'];
?>
